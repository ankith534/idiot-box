# idiot-box

It's a Movie Downloading website,where you will get required link to download a particular movie.I had used
SCSS, Bootstrap to make it more attractive.
I had used nodejs as server side language and mongodb as database


![alt text](https://user-images.githubusercontent.com/56197565/89974160-e5a56300-dc7f-11ea-8d56-a2322400651c.png?raw=true)

![alt text](https://user-images.githubusercontent.com/56197565/89974154-e3430900-dc7f-11ea-93a0-168c6b3f7255.png?raw=true)
